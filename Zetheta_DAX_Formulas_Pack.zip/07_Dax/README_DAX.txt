# Zetheta Project 1B — DAX Measures
# Bond Portfolio Convexity Sensitivity AI Agent
#
# IMPORTANT:
# These are starter DAX measures. Before using them, check the actual table and
# column names in your Power BI model and replace names as needed.
# Assumed tables/columns:
#   BondPortfolio[MarketValue]
#   BondPortfolio[YTM]
#   BondPortfolio[ModifiedDuration]
#   BondPortfolio[Convexity]
#   BondPortfolio[BondID]
#   MonteCarlo[Loss]
#   ScenarioComparison[Scenario]
#   ScenarioComparison[DurationEffect]
#   ScenarioComparison[ConvexityEffect]
#   ScenarioComparison[TotalPnL]
#
# Create these measures in Power BI: Modeling > New measure.
