# Zetheta Project 1B — Final Submission Pack

**Project:** Data Analyst — Convexity Sensitivity AI Agent  
**Prepared by:** Jaswanth Goud

## Package contents
- `01_Documentation/` — final Word project report
- `02_Presentation/` — 12-slide PowerPoint presentation
- `03_Excel/` — summary workbook with Executive Summary, Scenario Comparison, Monte Carlo Risk, and QA Checklist sheets
- `04_Streamlit_AI_Agent/` — Streamlit application, requirements, and the three input CSV files
- `05_Project_Brief/` — original project brief PDF

## Run the Streamlit application
1. Install Python 3.10+ if it is not already installed.
2. Open Command Prompt or PowerShell in the `04_Streamlit_AI_Agent` folder.
3. Install dependencies:
   `pip install -r requirements.txt`
4. Start the app:
   `python -m streamlit run app.py`
5. Open the local address printed in the terminal (usually `http://localhost:8501`).

The app searches for the CSV files in its folder and common subfolders. The supplied files are placed in `data/`; if automatic loading does not find them, use the CSV upload controls in the app sidebar.

## Before submitting to the project portal
- Check the project instructions and upload the requested files/formats.
- If the portal specifically requires a Power BI `.pbix` file, export/copy your actual `.pbix` file from your own Power BI project into this package before submission. The `.pbix` file was not present in the available materials used to create this pack.
- If the portal requires screenshots as evidence, add your own final Power BI and Streamlit screenshots.
- Verify your name, project title, and any required declaration fields.

## Accuracy note
The portfolio and risk figures in the report and presentation were transcribed from the demonstrated app screenshots and have not been independently reconciled in those documents to every raw CSV row/formula. Duration-convexity figures are approximations rather than full bond-by-bond repricing. The Risk Agent Q&A in the app is rule-based, not an LLM-powered agent. Please validate numerical results against the source data before presenting them as audited financial results.

This pack does not itself submit files to Zetheta or any external portal.
